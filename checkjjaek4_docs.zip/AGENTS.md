# AGENTS.md

## 목적

이 문서는 `checkjjaek4` 저장소에서 작업하는 에이전트(Codex 등)가
프로젝트의 기본 작업 원칙과 문서 참조 순서를 일관되게 따르도록 하기 위한 안내서다.

---

## 기본 작업 원칙

- Rails 관례(Rails way)를 최우선으로 따른다.
- 꼭 필요하지 않다면 비표준 구조, 과한 추상화, 과한 메타프로그래밍을 피한다.
- 작은 단위로 읽고, 작은 단위로 수정하고, 변경 이유를 분명히 남긴다.
- 새로운 코드를 만들 때는 현재 코드베이스의 구조와 스타일에 최대한 일관되게 맞춘다.
- UI 문구나 마크업만 보고 성급히 수정하지 말고, 관련 도메인/흐름/정책부터 확인한다.
- view에는 가능한 한 로직을 최소화하고, 권한/분기/도메인 판단은 controller, policy, model, helper 등 적절한 계층에 둔다.
- 권한 판단은 view에서 직접 해결하지 말고, controller와 policy를 기준으로 읽기 쉽게 유지한다.
- 문자열이 새로 추가되거나 변경될 때는 처음부터 `locales`를 함께 고려해 제안한다.

---

## 문서 우선순위

작업 전 아래 문서를 가능한 먼저 확인한다.

1. `AGENTS.md`

2. 현재 시스템 구조 요약
   - `docs/architecture/current_system.md`
     - 현재 구현 상태와 주요 화면 흐름 요약
   - `docs/architecture/authorization.md`
     - 권한 구조와 policy 기준 정리
   - `docs/architecture/jjaek_visibility.md`
     - visibility 의미와 적용 범위 정리

3. 현재 활성 reboot 기준 문서
   - `docs/specs/bookjjaek_reboot_spec.md`
   - `docs/reboot/reboot_plan.md`

4. 현재 작업과 직접 관련된 spec 문서
   - 예: `docs/specs/book_search_mvp.md`

5. 테스트 전략 문서
   - `docs/testing/rspec_strategy.md`

6. 관련 아키텍처/정책 문서
   - `docs/architecture/*.md`

7. 레거시/아카이브 문서
   - `docs/legacy/*.md`
   - `docs/archive/*.md`

원칙:

- 현재 `checkjjaek4`의 활성 기준은
  `AGENTS.md` → `docs/architecture/current_system.md` → `docs/architecture/authorization.md` → `docs/architecture/jjaek_visibility.md` → `docs/specs/bookjjaek_reboot_spec.md` → `docs/reboot/reboot_plan.md`
  순으로 먼저 읽는 것을 기본값으로 둔다.
- `docs/archive/*`는 과거 판단 기록 보존용이며, 현재 활성 spec보다 우선하지 않는다.
- `docs/legacy/*`는 checkjjaek3 및 초기 분석 기록 참고용이며, 현재 활성 spec보다 우선하지 않는다.
- 기존 문서를 함부로 수정하지 말라는 원칙은 오래된 기준을 active docs에 계속 보존하라는 뜻이 아니다.
- 새 기능이나 새 canonical spec이 기존 기준을 대체하면, 기존 active 문서는 갱신·통합·삭제하거나 필요 시 `docs/archive/`로 이동한다.
- spec만 보지 말고, 해당 spec의 판단 근거가 되는 정책/구조 문서가 있으면 함께 먼저 확인한다.
- 문서가 아직 없거나 부족하면, 먼저 문서를 보강한 뒤 구현에 들어간다.

---

## bookjjaek 리부트 작업 규칙

- 현재 리부트 작업의 기준 문서는 아래 두 개다.
  - `docs/specs/bookjjaek_reboot_spec.md`
  - `docs/reboot/reboot_plan.md`
- 현재 구현 상태와 주요 흐름은 `docs/architecture/current_system.md`를 기준으로 빠르게 파악한다.
- 권한 구조와 visibility 상세는 아래 문서를 함께 본다.
  - `docs/architecture/authorization.md`
  - `docs/architecture/jjaek_visibility.md`
- `checkjjaek4`는 기존의 post 중심 SNS를 억지로 확장하는 프로젝트가 아니라,
  **책과 서재가 중요한 문맥을 이루는 독서 커뮤니티 서비스로 리부트 중인 프로젝트**로 본다.

- 여러 책장, 그룹, Topic, 작가 정규화, 인용문 기능, 범용 SNS 확장은 현재 MVP 범위가 아니다.
- 복잡한 리부트 작업은 한 번에 크게 수정하지 말고,
  **분석 → 계획 제안 → diff 제시 → 승인 후 반영** 순서를 지킨다.
- 새 repo를 만드는 대신, 같은 repo 안에서 점진적으로 리부트하는 방향을 기본값으로 둔다.
- 핵심 도메인과 현재 구현 흐름은 `docs/architecture/current_system.md`를 따른다.
- 제품 방향과 흔들리면 안 되는 도메인 원칙은 `docs/specs/bookjjaek_reboot_spec.md`를 따른다.

---

## 현재 시스템 해석 원칙

- 현재 구현 상태와 주요 화면 흐름은 `docs/architecture/current_system.md`를 따른다.
- 권한 구조와 visibility 해석은
  `docs/architecture/authorization.md`,
  `docs/architecture/jjaek_visibility.md`를 함께 따른다.
- 장기 제품 방향과 MVP 범위 판단은 `docs/specs/bookjjaek_reboot_spec.md`와 `docs/reboot/reboot_plan.md`를 따른다.

---

## ReJjaek 규칙

- `ReJjaek`은 다른 `Jjaek`을 인용하거나 응답한 새 `Jjaek`이다.
- 원문보다 넓게 공개할 수 없다.
- 원문이 `나만 보기`면 `ReJjaek`을 만들 수 없다.
- 원문 접근 권한이 사라지면 `ReJjaek`도 비노출되어야 한다.
- 따라서 조회 시에도 원문 접근 권한 재검사가 필요하다.
- 이 규칙은 model validation만으로 끝내지 말고,
  policy / policy scope / request spec 관점에서도 함께 고정한다.
- `ReJjaek`은 별도 1급 모델로 성급히 분리하지 않고,
  우선 `Jjaek`의 인용/응답 문맥으로 해석한다.

---

## 그룹/교실 기능 해석 원칙

- 그룹 기능은 단순한 커뮤니티 확장이 아니라,
  향후 **교실에서 실제로 쓰이는 독서 도구** 방향과 연결될 수 있다.
- 다만 현재는 그룹 기능을 먼저 확장하지 않고,
  `짹 흐름 → 책/서재 문맥 → 책활동 후속 도입` 코어를 우선 안정화한다.
- 그룹이 도입되더라도, 학생 개인의 서재/기록이 source of truth이고
  그룹은 그 활동 중 공유 가능한 부분을 함께 보는 층으로 해석한다.

---

## 변경 승인 원칙

- 기본적으로 파일을 바로 수정하지 말고, 먼저 변경 계획과 diff/patch 요약을 제시한다.
- 기본 순서는 **diff 제시 → 사용자 승인 → 실제 반영** 이다.
- 사용자가 승인하기 전에는 실제 파일 수정(write)을 하지 않는다.
- 문서 작업도 동일하게 적용한다.
- 사용자가 “바로 반영해도 된다”고 명시한 경우에만 즉시 수정한다.
- 변경 범위가 클 경우, 파일별 수정 계획을 먼저 요약한다.

---

## 정리/복구 원칙

- 구현 방향이 바뀌어 더 이상 필요 없어졌다면, 관련 파일과 코드도 함께 정리 대상으로 본다.
- 새 구조를 넣으면서 불필요해진 controller, view, helper, route, 테스트, 문서가 남지 않도록 정리한다.
- 무언가를 추가했다가 방향을 바꿔 되돌리는 경우,
  남겨둘 이유가 분명하지 않다면 최대한 작업 전 상태에 가깝게 복구한다.
- 임시 호환 코드를 오래 남기는 것보다,
  현재 승인된 spec과 구조 기준으로 일관되게 정리하는 쪽을 우선한다.
- 다만 사용자가 직접 만든 변경이나, 현재 작업과 무관한 기존 변경은 임의로 되돌리지 않는다.
- 삭제/복구가 필요한 파일이 있다면, 반영 전에 정리 대상 파일 목록을 먼저 diff 요약에 포함한다.
- archive/legacy로 이동한 문서를 정리할 때는
  기존 위치에 중복 파일이 남지 않도록 주의한다.

---

## spec 기반 작업 규칙

- 작업은 `docs/specs/*.md`를 기준으로 진행한다.
- 새로운 기능이나 리팩토링 단위가 필요하면 먼저 해당 spec 초안을 제안한다.
- 관련 spec이 아직 없다면, 바로 구현에 들어가지 말고 먼저 spec 초안을 제안한다.
- spec 변경이 필요하면 먼저 제안하고 승인 후 반영한다.
- 임의로 spec 밖의 기능을 추가하지 않는다.
- 별도 지시가 없으면, 구현과 함께 관련 문서도 같이 갱신한다.
- 코드 변경으로 문서화된 현재 구현/정책/남은 작업이 달라지는 경우, 해당 내용의 기준 문서만 함께 갱신한다.
- 이때 관련 없는 다른 문서까지 함께 수정하려고 하지 않는다.
- 코드 변경으로 현재 구현이 달라진 경우, `docs/architecture/current_system.md`를 포함한 해당 기준 문서를 함께 갱신한다.
- 새 기능이 기존 spec의 기준을 대체하면 active spec을 둘로 나누어 병렬 유지하지 않는다.
- canonical spec을 하나로 정하고, 중복되는 기존 spec은 필요한 내용을 흡수한 뒤 삭제하거나 archive로 이동한다.
- 이때 `docs/architecture/current_system.md`, `docs/reboot/reboot_plan.md` 등 참조 문서도 새 canonical 기준만 가리키도록 정리한다.
- 작업 결과는 git 커밋으로 남긴다.

---

## 아키텍처/구현 원칙

- `checkjjaek4`의 서버측 권한 판단은 **Pundit policy 중심**으로 유지한다.
- controller에 권한 조건식을 직접 늘어놓기보다,
  controller는 가능한 한 `authorize`, `policy_scope`를 호출하는 자리로 남긴다.
- 단건 권한 판단은 policy에, 목록 조회 범위 판단은 policy scope에 둔다.
- 권한 규칙과 조회 가능 범위가 화면마다 다르면,
  그 차이를 controller 조건문으로 풀기보다 policy/policy scope 구조로 먼저 설명 가능해야 한다.
- view에서 권한 분기를 추가해야 할 때도,
  가능한 한 controller와 policy에서 이미 정리된 상태를 소비하도록 만든다.
- 레거시 `checkjjaek3`의 CanCanCan 구조는 참고 대상일 뿐,
  새 프로젝트의 기본 권한 체계로 그대로 가져오지 않는다.
- Turbo 응답과 HTML 응답은 둘 다 깨지지 않도록 주의하고,
  응답 방식은 가능한 한 일관되게 유지한다.
- 새 기능을 추가할 때는 먼저 현재 구조와 naming, partial 분리 방식, controller 책임 범위를 확인하고 그 흐름을 따른다.
- 불필요한 새 객체, 새 패턴, 새 계층을 성급히 늘리지 않는다.

---

## 테스트 원칙

- 테스트의 목적은 coverage 수치가 아니라 confidence 확보이다.
- 테스트 전략은 프로젝트의 `docs/testing/rspec_strategy.md`를 우선 기준으로 따른다.
- 핵심 도메인 규칙, 권한, 상태 전이, request 흐름을 우선 테스트한다.
- 특히 아래를 우선 고정한다.
  - `Book` / `BookshelfEntry` / `BookshelfEntrySticker`
  - 검색 결과 import 흐름
  - `Jjaek` / `ReJjaek`
  - 공개 범위와 조회 가능 범위
  - policy scope
  - request 흐름
- brittle한 HTML 구조 테스트는 지양한다.
- system spec은 핵심 happy path 중심으로 최소화한다.
- RSpec 스타일은 readable > clever 원칙을 따른다.
- 과도한 shared context, helper, abstraction을 피한다.
- 기존 테스트와 중복되는 저가치 테스트를 늘리지 않는다.

---

## 커밋 원칙

- 작업 결과는 git 커밋으로 남긴다.
- 가능하면 아래 항목이 드러나게 작성한다.
  - What: 무엇을 변경했는가
  - Why: 왜 변경했는가
  - Risk: 영향/부작용이 있는가
  - Verify: 무엇으로 확인했는가
- 너무 짧은 한 줄 메시지는 피한다.
- commit message는 한국어 우선으로 작성한다.

---

## 작업 완료 후 기대사항

- 변경 이유를 짧게 설명할 수 있어야 한다.
- 가능하면 관련 테스트를 함께 추가/수정한다.
- 새 규칙이 생겼다면 관련 문서도 함께 갱신한다.
- 변경 범위가 크면 후속 작업 포인트를 짧게 남긴다.
